import React, { Fragment } from 'react';
import logo from './logo.svg';
import './App.css';
import Greet from './components/Greet'
import Meeting from './components/Meeting'
import Message from './components/Message'
import Counter from './components/Counter'
import ParentComponent from './components/ParentComponent';
import UserComponent from './components/UserComponent';
import ListRender from './components/listRender';
import ListDemo from './components/ListDemo';
import FragmentDemo from './components/FragmentDemo';
import ParentComp from './components/ParentComp';
import Error from './components/error';
import ErrorBoundary from './components/ErrorBoundary';
import CounterClick from './components/CounterClick';
import HoverCounter from './components/HoverCounter';

function App() {
  return (
    <div className="App">
      <CounterClick></CounterClick>
      <HoverCounter></HoverCounter>
        {/* <ErrorBoundary><Error name="Batman"></Error></ErrorBoundary>
        <ErrorBoundary><Error name="Joker"></Error></ErrorBoundary> */}
        {/* <Greet name="I am Greet">
          <p>Child 1 - Greet</p>
          <button>Greet 1</button>
        </Greet>
        <Meeting name="I am Meeting">
          <p>Child 1 - Meeting</p>
          <button>Meeting 1</button>
        </Meeting>
        <Message/>
        <Counter></Counter>
        <ParentComponent/>
        <UserComponent></UserComponent>
        <ListRender></ListRender> */}
        {/* <ListDemo></ListDemo>
        <FragmentDemo></FragmentDemo> */}
        {/* <ParentComp></ParentComp> */}
    </div>
  );
}

export default App;
