import React,{Component} from 'react'
import RealComp from './RealComp'
import PureComp from './PureComp'

class ParentComp extends Component{

    constructor(){
        super()
        this.state = {
            name:'Sachi'
        }
    }

    componentDidMount(){
        setInterval(() => {
            this.setState({
                name:'Sachi'
            })
    }, 2000);}
    
    render(){
        console.log("*************Parent Comp*****************")
        return(
            <div>
                <RealComp name={this.state.name}></RealComp>
                <PureComp name={this.state.name}></PureComp>
            </div>
        )
    }
}

export default ParentComp