import React from 'react'

const ChildComponent = (props) =>{
    return(
        <div>
            <button onClick = {() => props.handler("2")}>Child Click</button>
        </div>
    )
}

export default ChildComponent