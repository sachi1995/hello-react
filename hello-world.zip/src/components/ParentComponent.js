import React,{Component} from 'react'
import Child from './ChildCComponent'

class ParentComponent extends Component{

    constructor(){
        super()
        this.state = {
            msg : 'Hi'
        }
        this.parentFunc = this.parentFunc.bind(this);
    }

    parentFunc(input){
        this.setState({
            msg:`${input} bye!!!!`
        })
    }
    render(){
        return(
            <div>
                <p>{this.state.msg}</p>
                <Child handler ={this.parentFunc}></Child>
            </div>
        )
    }
}

export default ParentComponent