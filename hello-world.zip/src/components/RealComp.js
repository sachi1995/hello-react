import React,{Component} from 'react'

class RealComp extends Component{
    render(){
        console.log("------------Real Comp-------------------")
        return(
            <div>
                Hi Real Component {this.props.name}
            </div>
        )
    }
}

export default RealComp