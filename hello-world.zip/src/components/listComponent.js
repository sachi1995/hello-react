import React, {Component} from 'react'
import '../style.css'

class ListComponent extends Component{
    render(){
        let colorName = this.props.show ? 'primary' : null
        return(
            <div>
                <p>I am {this.props.name}</p>
                <p className={colorName}>Hello</p>
            </div>
        )
    }
}
export default ListComponent