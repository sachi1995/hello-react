import React,{Component} from 'react'

class Meeting extends Component{
    render(){
        console.log(`meeting + ${this.props}`);
        return (
            <div>
                <h1>{this.props.name}</h1>
                {this.props.children}
            </div>
        )
    }
}

export default Meeting