import React,{Component, Fragment} from 'react'

class FragmentDemo extends Component{
    render(){
        return(
            <React.Fragment>
                <p>HI I am a fragment</p>
            </React.Fragment>
        )
    }
}

export default FragmentDemo