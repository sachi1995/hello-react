import React,{Component} from 'react'

class ErrorBoundary extends Component{

    constructor(){
        super()
        this.state = {
            isError:false
        }
    }

    static getDerivedStateFromError(error){
        return{
            isError:true
        }
    }

    render(){
        if(this.state.isError === true){
            return(<h1>Something is wrong!!!</h1>)
        }else{
            return (this.props.children)
        }
    }
}

export default ErrorBoundary