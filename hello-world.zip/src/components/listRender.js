import React, {Component} from 'react'
import ListComponent from './listComponent'

class ListRender extends Component{
    render(){
        const namesArr = ['sachi','pulkit','mummy','papa']
        const nameList =  namesArr.map((i) => 
            <ListComponent show={false} key={i} name={i}></ListComponent>)
        return(
            <div>
                {nameList}
            </div>
        )
    }
}

export default ListRender