import React,{Component} from 'react'


const UpdatedComponent = (OriginalComponent) =>{
    class NewComponent extends Component{

        constructor(){
            super()
            this.state = {
                count:0
            }
        }
    
        hoverCount = ()=>{
            this.setState((prevState) =>{
                return {count : prevState.count + 1}
            })
        }

        render(){
            return(
                <OriginalComponent name="Sachi" number={this.state.count} incrementCount={this.hoverCount}></OriginalComponent>
            )
        }
    }
    return NewComponent
}

export default UpdatedComponent 