import React,{Component} from 'react'
import UpdatedComponent from './withCounter'

class HoverCounter extends Component{
   
    render(){
        return(
        <h2 onMouseEnter={this.props.incrementCount}>Hover {this.props.number} times by {this.props.name}</h2>
        )
    }
}

export default UpdatedComponent(HoverCounter)