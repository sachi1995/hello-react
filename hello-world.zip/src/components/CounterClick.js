import React, { Component } from 'react'
import UpdatedComponent from './withCounter'

class CounterClick extends Component{
    
    render(){
        return(
            <div>
                <h1>{this.props.name}</h1>
                <button onClick={this.props.incrementCount}>Clicked {this.props.number} times</button>
            </div>
        )
     }

}

export default UpdatedComponent(CounterClick)