import React,{Component} from 'react'

class UserComponent extends Component{

    constructor(){
        super();
        this.state = {
            isLoggedIn : false
        }
    }
    render(){
        return(
            <div>
                <p>Condition</p>
                {this.state.isLoggedIn && <div>Welcome Sachi</div>}
            </div>
            
        )
    }
}

export default UserComponent