import React , {Component} from 'react'

class Message extends Component{

    constructor(){
        super();
        this.state = {
            message: 'Hi Visitor'
        }
    }

    buttonClicked(){
        this.setState({
            message : 'Thanks for clicking'
        });
    }
    render(){
        return(
            <div>
                <h1>{this.state.message}</h1>
                <button onClick = {() => this.buttonClicked()}>Click Me</button>
            </div>
        )
    }

}

export default Message