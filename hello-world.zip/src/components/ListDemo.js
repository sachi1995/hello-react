import React,{Component} from 'react'

class ListDemo extends Component{
    constructor(){
        super()
        this.state = {
            name:'',
            options:'React3'
        }
    }

    handleName = (event) =>{
        this.setState({
            name: event.target.value
        })
    }

    handleOption = (event) =>{
        this.setState({
           options:event.target.value 
        })
    }

    handleSubmit = (event)=>{
        alert(`Hi, I am ${this.state.name} and I have chosen ${this.state.options}`)
        event.preventDefault()
    }

    render(){
        return(
            <div>
                <form onSubmit={this.handleSubmit}>
                    <div>
                        <label>Username</label>
                        <input type="text" value={this.state.name} onChange={this.handleName}></input>
                    </div>
                    <div>
                        <label>Option</label>
                        <select value={this.state.options} onChange={this.handleOption}>
                            <option value="React1">React1</option>
                            <option value="React2">React2</option>
                            <option value="React3">React3</option>
                        </select>
                    </div>
                    <button type="submit">Submit</button>
                </form>
            </div>
        )
    }

}

export default ListDemo